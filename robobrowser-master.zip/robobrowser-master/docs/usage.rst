========
Usage
========

To use robobrowser in a project::

	import robobrowser