============
Installation
============

At the command line::

    $ easy_install robobrowser

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv robobrowser
    $ pip install robobrowser
